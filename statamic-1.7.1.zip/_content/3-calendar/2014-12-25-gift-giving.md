---
title: Gift Giving
---
I collect the figures that I have hand-carved throughout the year and disperse them among the town's children.