---
title: Spring Dance
---
I've concocted an elaborate dance that is nearly foolproof in bringing about the change of seasons. By watching the elk migrations carefully, observing wolf and fox mating patterns, and meeting with the cold, pale ghost of a Native American medicine man, I've collected the knowledge required to dance the snow away.