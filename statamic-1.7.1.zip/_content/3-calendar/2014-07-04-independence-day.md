---
title: Independence Day
---
Celebrate with makeshift fireworks made from kidney stones I've collected over the years.