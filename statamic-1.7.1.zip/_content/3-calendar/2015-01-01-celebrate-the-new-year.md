---
title: Celebrate the New Year
---
It's a new year. Again. I plan to celebrate with a small feast of fennel and snow lily stuffed hare covered in a pine nut glaze.