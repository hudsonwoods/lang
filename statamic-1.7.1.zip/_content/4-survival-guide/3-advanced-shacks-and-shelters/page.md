---
title: Advanced Shacks & Shelters
_template: section
---
Time to build real shelters.