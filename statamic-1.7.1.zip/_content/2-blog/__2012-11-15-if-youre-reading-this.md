---
title: "If You're Reading This... (Draft)"
categories:
  - wilderness
  - will
---
Drafting; do not publish!

If you're reading this, it means you've found my body...